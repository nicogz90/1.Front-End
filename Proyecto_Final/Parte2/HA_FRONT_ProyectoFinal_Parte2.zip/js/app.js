// Código JavaScript general para toda la aplicación.
// En este ejemplo, este archivo queda vacío (se podría borrar).
